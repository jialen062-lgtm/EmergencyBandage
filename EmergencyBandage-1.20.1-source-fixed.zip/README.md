# Emergency Bandage — Minecraft 1.20.1 Forge

- Minecraft: 1.20.1
- Forge: 47.x
- Java: 17
- Default key: F
- Trigger: health at or below 50%
- Hold for 100 ticks (5 seconds)
- Restore 30% of maximum health, capped at maximum health
- Releasing the key cancels progress
- Progress is server-authoritative for multiplayer

## Build
Run `./gradlew build` (Windows: `gradlew.bat build`). The jar will be in `build/libs/`.

## Important key conflict
Minecraft uses F for "Swap Item With Offhand" by default. To avoid both actions triggering,
open Options → Controls and rebind "Swap Item With Offhand" to another key (for example G).
The bandage action remains on F. No cooldown is currently implemented.

## Sound
The included `bandage.ogg` is an original synthesized cloth-rustle effect, not extracted from
a commercial game. It can be replaced with a properly licensed sound at
`assets/emergencybandage/sounds/bandage.ogg`.
