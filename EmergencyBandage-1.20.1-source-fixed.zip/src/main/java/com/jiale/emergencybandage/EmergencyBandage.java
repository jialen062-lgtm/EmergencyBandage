package com.jiale.emergencybandage;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

@Mod(EmergencyBandage.MODID)
public class EmergencyBandage {
    public static final String MODID = "emergencybandage";
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);
    public static final RegistryObject<SoundEvent> BANDAGE =
            SOUNDS.register("bandage", () -> SoundEvent.createVariableRangeEvent(
                    new ResourceLocation(MODID, "bandage")));

    public EmergencyBandage() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        SOUNDS.register(bus);
        NetworkHandler.register();
    }
}
