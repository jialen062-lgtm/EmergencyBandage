package com.jiale.emergencybandage;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber(modid = EmergencyBandage.MODID)
public final class BandageServerHandler {
    private static final Map<UUID, Integer> PROGRESS = new ConcurrentHashMap<>();

    private BandageServerHandler() {}

    public static void setHolding(ServerPlayer player, boolean holding) {
        if (player == null) return;
        UUID id = player.getUUID();
        if (!holding) {
            PROGRESS.remove(id);
            NetworkHandler.sendProgress(player, 0);
            return;
        }
        if (!player.isAlive() || player.isSpectator()
                || player.getHealth() >= player.getMaxHealth() * 0.5f) return;
        PROGRESS.putIfAbsent(id, 0);
        NetworkHandler.sendProgress(player, PROGRESS.getOrDefault(id, 0));
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        UUID id = player.getUUID();
        Integer current = PROGRESS.get(id);
        if (current == null) return;

        if (!player.isAlive() || player.isSpectator()
                || player.getHealth() >= player.getMaxHealth() * 0.5f) {
            PROGRESS.remove(id);
            NetworkHandler.sendProgress(player, 0);
            return;
        }

        int next = current + 1;
        if (next >= 100) {
            PROGRESS.remove(id);
            float healed = Math.min(player.getMaxHealth(),
                    player.getHealth() + player.getMaxHealth() * 0.30f);
            player.setHealth(healed);
            player.playSound(EmergencyBandage.BANDAGE.get(), 1.0f, 0.95f + player.getRandom().nextFloat() * 0.1f);
            NetworkHandler.sendProgress(player, 0);
        } else {
            PROGRESS.put(id, next);
            if (next % 5 == 0) NetworkHandler.sendProgress(player, next);
        }
    }
}
