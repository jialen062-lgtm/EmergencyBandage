package com.jiale.emergencybandage;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = EmergencyBandage.MODID, value = Dist.CLIENT)
public final class BandageClientHandler {
    public static KeyMapping BANDAGE_KEY;
    private static boolean wasDown = false;
    public static int serverProgress = 0;

    private BandageClientHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null) {
            if (wasDown) NetworkHandler.sendState(false);
            wasDown = false;
            return;
        }
        boolean eligible = mc.player.getHealth() < mc.player.getMaxHealth() * 0.5f;
        boolean down = eligible && BANDAGE_KEY != null && BANDAGE_KEY.isDown();
        if (down != wasDown) NetworkHandler.sendState(down);
        wasDown = down;
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.player.getHealth() >= mc.player.getMaxHealth() * 0.5f) return;

        var graphics = event.getGuiGraphics();
        int width = mc.getWindow().getGuiScaledWidth();
        int y = mc.getWindow().getGuiScaledHeight() - 48;
        String prompt = "按 F 键包扎";
        int textWidth = mc.font.width(prompt);
        int totalWidth = textWidth + 8 + 5 * 14;
        int x = (width - totalWidth) / 2;
        graphics.drawString(mc.font, prompt, x, y, 0xFFFF3333, true);

        if (wasDown || serverProgress > 0) {
            int barX = x + textWidth + 8;
            for (int i = 0; i < 5; i++) {
                int color = serverProgress >= (i + 1) * 20 ? 0xFFFF3333 : 0xFF555555;
                graphics.fill(barX + i * 14, y + 1, barX + i * 14 + 11, y + 8, color);
                graphics.fill(barX + i * 14, y + 1, barX + i * 14 + 11, y + 2, 0xFFAAAAAA);
            }
        }
    }
}
