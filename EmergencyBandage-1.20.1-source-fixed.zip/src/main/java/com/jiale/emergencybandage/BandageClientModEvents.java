package com.jiale.emergencybandage;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = EmergencyBandage.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class BandageClientModEvents {
    private BandageClientModEvents() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        BandageClientHandler.BANDAGE_KEY = new KeyMapping(
                "key.emergencybandage.bandage",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_F,
                "key.categories.emergencybandage");
        event.register(BandageClientHandler.BANDAGE_KEY);
    }
}
