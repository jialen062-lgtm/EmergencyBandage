package com.jiale.emergencybandage;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.SimpleChannel;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import java.util.function.Supplier;

public final class NetworkHandler {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(EmergencyBandage.MODID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);
    private static int id = 0;

    private NetworkHandler() {}

    public static void register() {
        CHANNEL.messageBuilder(BandageStatePacket.class, id++)
                .encoder(BandageStatePacket::encode)
                .decoder(BandageStatePacket::decode)
                .consumerMainThread(BandageStatePacket::handle)
                .add();
        CHANNEL.messageBuilder(BandageProgressPacket.class, id++)
                .encoder(BandageProgressPacket::encode)
                .decoder(BandageProgressPacket::decode)
                .consumerMainThread(BandageProgressPacket::handle)
                .add();
    }

    public static void sendState(boolean holding) {
        CHANNEL.sendToServer(new BandageStatePacket(holding));
    }

    public static void sendProgress(ServerPlayer player, int ticks) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new BandageProgressPacket(ticks));
    }

    public record BandageStatePacket(boolean holding) {
        static void encode(BandageStatePacket p, FriendlyByteBuf b) { b.writeBoolean(p.holding); }
        static BandageStatePacket decode(FriendlyByteBuf b) { return new BandageStatePacket(b.readBoolean()); }
        static void handle(BandageStatePacket p, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> BandageServerHandler.setHolding(
                    ctx.get().getSender(), p.holding));
            ctx.get().setPacketHandled(true);
        }
    }

    public record BandageProgressPacket(int ticks) {
        static void encode(BandageProgressPacket p, FriendlyByteBuf b) { b.writeVarInt(p.ticks); }
        static BandageProgressPacket decode(FriendlyByteBuf b) { return new BandageProgressPacket(b.readVarInt()); }
        static void handle(BandageProgressPacket p, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> BandageClientHandler.serverProgress = Math.max(0, Math.min(100, p.ticks))));
            ctx.get().setPacketHandled(true);
        }
    }
}
